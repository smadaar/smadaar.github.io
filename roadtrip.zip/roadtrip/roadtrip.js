function getText(item) {
  return [item.title, item.type, item.notes, item.start, item.end]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
}

let currentRoadtripData = null;
let currentEditingState = null; // { dayIndex, itemIndex, mode }
let serverRoadtripData = null;

const ROADTRIP_STORAGE_KEY = 'roadtrip-planner-data';
const ROADTRIP_SOURCE_KEY = 'roadtrip-planner-source';

function cloneData(data) {
  return JSON.parse(JSON.stringify(data));
}

function createElement(tag, options = {}) {
  const element = document.createElement(tag);
  if (options.text) element.textContent = options.text;
  if (options.className) element.className = options.className;
  if (options.html) element.innerHTML = options.html;
  if (options.attrs) {
    Object.entries(options.attrs).forEach(([name, value]) => {
      element.setAttribute(name, value);
    });
  }
  return element;
}

function parseEditorJson(raw) {
  try {
    return { value: JSON.parse(raw) };
  } catch (error) {
    return { error };
  }
}

function isPlannerData(data) {
  return Boolean(data && Array.isArray(data.days));
}

function getBrowserStoredData() {
  try {
    const raw = localStorage.getItem(ROADTRIP_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return isPlannerData(parsed) ? parsed : null;
  } catch (error) {
    return null;
  }
}

function saveBrowserStoredData(data) {
  try {
    localStorage.setItem(ROADTRIP_STORAGE_KEY, JSON.stringify(data));
    localStorage.setItem(ROADTRIP_SOURCE_KEY, 'browser');
    return true;
  } catch (error) {
    return false;
  }
}

function clearBrowserStoredData() {
  try {
    localStorage.removeItem(ROADTRIP_STORAGE_KEY);
    localStorage.setItem(ROADTRIP_SOURCE_KEY, 'server');
    return true;
  } catch (error) {
    return false;
  }
}

function getPreferredConfigSource() {
  try {
    return localStorage.getItem(ROADTRIP_SOURCE_KEY) || 'browser';
  } catch (error) {
    return 'browser';
  }
}

function savePreferredConfigSource(source) {
  try {
    localStorage.setItem(ROADTRIP_SOURCE_KEY, source);
    return true;
  } catch (error) {
    return false;
  }
}

function updateJSONEditor() {
  const editorTextarea = document.getElementById('planner-json-editor');
  if (editorTextarea) {
    editorTextarea.value = JSON.stringify(currentRoadtripData, null, 2);
  }
}

function setEditorStatus(message, isError = false) {
  const status = document.getElementById('editor-status');
  if (!status) return;
  status.textContent = message;
  status.style.color = isError ? '#b91c1c' : '#0f172a';
}

function setConfigSourceValue(source) {
  const sourceSelect = document.getElementById('config-source');
  if (sourceSelect) {
    sourceSelect.value = source;
  }
}

function applyPlannerData(data, options = {}) {
  currentRoadtripData = cloneData(data);
  updateJSONEditor();
  renderPlanner(currentRoadtripData);

  if (options.saveToBrowser) {
    const saved = saveBrowserStoredData(currentRoadtripData);
    setConfigSourceValue('browser');
    if (options.statusMessage) {
      setEditorStatus(
        saved ? options.statusMessage : 'Planner updated, but browser storage could not be saved.',
        !saved
      );
    }
  } else if (options.source) {
    setConfigSourceValue(options.source);
  }
}

function createRoadtripJsSnippet(data) {
  return `const roadtripData = ${JSON.stringify(data, null, 2)};\n\nwindow.roadtripData = roadtripData;`;
}

// Modal management
function setupModalHandlers() {
  const modal = document.getElementById('item-modal');
  const modalTitle = document.getElementById('item-modal-title');
  const modalCloseBtn = modal.querySelector('.modal-close-btn');
  const modalCancelBtn = document.getElementById('modal-cancel-btn');
  const modalDeleteBtn = document.getElementById('modal-delete-btn');
  const itemForm = document.getElementById('item-form');

  function closeModal() {
    modal.classList.add('hidden');
    currentEditingState = null;
  }

  function populateForm(item = {}) {
    document.getElementById('item-type').value = item.type || 'Activity';
    document.getElementById('item-title').value = item.title || '';
    document.getElementById('item-start').value = item.start || '';
    document.getElementById('item-end').value = item.end || '';
    document.getElementById('item-notes').value = item.notes || '';
    document.getElementById('item-map-url').value = item.mapUrl || '';
    document.getElementById('item-direction-url').value = item.directionUrl || '';
    document.getElementById('item-from').value = item.from || '';
    document.getElementById('item-to').value = item.to || '';
    document.getElementById('item-travel-mode').value = item.travelMode || '';
  }

  function openModal(dayIndex, itemIndex) {
    currentEditingState = { dayIndex, itemIndex, mode: 'edit' };
    const day = currentRoadtripData.days[dayIndex];
    const item = day.items[itemIndex];

    modalTitle.textContent = 'Edit Item';
    modalDeleteBtn.classList.remove('hidden');
    populateForm(item);

    modal.classList.remove('hidden');
  }

  function openAddModal(dayIndex) {
    currentEditingState = { dayIndex, itemIndex: null, mode: 'add' };
    modalTitle.textContent = 'Add Item';
    modalDeleteBtn.classList.add('hidden');
    populateForm({
      type: 'Activity',
      title: '',
      notes: ''
    });

    modal.classList.remove('hidden');
  }

  modalCloseBtn.addEventListener('click', closeModal);
  modalCancelBtn.addEventListener('click', closeModal);
  modalDeleteBtn.addEventListener('click', () => {
    if (!currentEditingState || currentEditingState.mode !== 'edit') {
      return;
    }

    const { dayIndex, itemIndex } = currentEditingState;
    currentRoadtripData.days[dayIndex].items.splice(itemIndex, 1);
    applyPlannerData(currentRoadtripData, {
      saveToBrowser: true,
      statusMessage: 'Deleted item and saved browser copy.'
    });
    closeModal();
  });

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeModal();
    }
  });

  itemForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const updatedItem = {
      type: document.getElementById('item-type').value,
      title: document.getElementById('item-title').value,
      start: document.getElementById('item-start').value || undefined,
      end: document.getElementById('item-end').value || undefined,
      notes: document.getElementById('item-notes').value || undefined,
      mapUrl: document.getElementById('item-map-url').value || undefined,
      directionUrl: document.getElementById('item-direction-url').value || undefined,
      from: document.getElementById('item-from').value || undefined,
      to: document.getElementById('item-to').value || undefined,
      travelMode: document.getElementById('item-travel-mode').value || undefined,
    };

    // Remove undefined properties
    Object.keys(updatedItem).forEach(
      (key) => updatedItem[key] === undefined && delete updatedItem[key]
    );

    const { dayIndex, itemIndex, mode } = currentEditingState;
    if (mode === 'add') {
      currentRoadtripData.days[dayIndex].items.push(updatedItem);
    } else {
      currentRoadtripData.days[dayIndex].items[itemIndex] = updatedItem;
    }

    applyPlannerData(currentRoadtripData, {
      saveToBrowser: true,
      statusMessage: mode === 'add'
        ? 'Added item and saved browser copy.'
        : 'Updated item and saved browser copy.'
    });
    closeModal();
  });

  window.openItemModal = openModal;
  window.openAddItemModal = openAddModal;
}

// Reorder functions
function moveItemUp(dayIndex, itemIndex) {
  if (itemIndex === 0) return; // Already at top
  const items = currentRoadtripData.days[dayIndex].items;
  [items[itemIndex], items[itemIndex - 1]] = [items[itemIndex - 1], items[itemIndex]];
  applyPlannerData(currentRoadtripData, {
    saveToBrowser: true,
    statusMessage: 'Moved item and saved browser copy.'
  });
}

function moveItemDown(dayIndex, itemIndex) {
  const items = currentRoadtripData.days[dayIndex].items;
  if (itemIndex === items.length - 1) return; // Already at bottom
  [items[itemIndex], items[itemIndex + 1]] = [items[itemIndex + 1], items[itemIndex]];
  applyPlannerData(currentRoadtripData, {
    saveToBrowser: true,
    statusMessage: 'Moved item and saved browser copy.'
  });
}

window.moveItemUp = moveItemUp;
window.moveItemDown = moveItemDown;

function setupPlannerEditor(initialData, serverData, initialSource) {
  const editorToggle = document.getElementById('toggle-editor');
  const editorContainer = document.getElementById('editor-container');
  const editorTextarea = document.getElementById('planner-json-editor');
  const sourceSelect = document.getElementById('config-source');
  const saveBrowserButton = document.getElementById('save-browser-storage');
  const resetServerButton = document.getElementById('reset-server');
  const previewButton = document.getElementById('preview-changes');
  const saveButton = document.getElementById('save-whatsapp');
  const copyButton = document.getElementById('copy-js');
  const status = document.getElementById('editor-status');

  if (!editorToggle || !editorContainer || !editorTextarea || !sourceSelect || !saveBrowserButton || !resetServerButton || !previewButton || !saveButton || !copyButton || !status) {
    return;
  }

  function setStatus(message, isError = false) {
    status.textContent = message;
    status.style.color = isError ? '#b91c1c' : '#0f172a';
  }

  function updateEditorTextarea(data) {
    editorTextarea.value = JSON.stringify(data, null, 2);
  }

  function openWhatsAppWithText(text) {
    const encoded = encodeURIComponent(text);
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(whatsappUrl, '_blank');
  }

  sourceSelect.value = initialSource;

  editorToggle.addEventListener('click', () => {
    const hidden = editorContainer.classList.toggle('hidden');
    editorToggle.textContent = hidden ? 'Edit planner (JSON)' : 'Hide planner editor';
  });

  sourceSelect.addEventListener('change', () => {
    if (sourceSelect.value === 'browser') {
      const storedData = getBrowserStoredData();
      if (!storedData) {
        sourceSelect.value = 'server';
        setStatus('No browser copy found. Using server config.', true);
        return;
      }

      savePreferredConfigSource('browser');
      applyPlannerData(storedData, { source: 'browser' });
      setStatus('Loaded planner from browser storage.');
      return;
    }

    savePreferredConfigSource('server');
    applyPlannerData(serverData, { source: 'server' });
    setStatus('Loaded planner from server config.');
  });

  saveBrowserButton.addEventListener('click', () => {
    const parsed = parseEditorJson(editorTextarea.value);
    if (parsed.error) {
      setStatus(`Invalid JSON: ${parsed.error.message}`, true);
      return;
    }
    if (!isPlannerData(parsed.value)) {
      setStatus('Planner JSON must include a days array.', true);
      return;
    }

    applyPlannerData(parsed.value, {
      saveToBrowser: true,
      statusMessage: 'Saved planner to browser storage.'
    });
  });

  resetServerButton.addEventListener('click', () => {
    clearBrowserStoredData();
    applyPlannerData(serverData, { source: 'server' });
    setStatus('Reset planner from server config.');
  });

  previewButton.addEventListener('click', () => {
    const parsed = parseEditorJson(editorTextarea.value);
    if (parsed.error) {
      setStatus(`Invalid JSON: ${parsed.error.message}`, true);
      return;
    }
    if (!isPlannerData(parsed.value)) {
      setStatus('Planner JSON must include a days array.', true);
      return;
    }
    applyPlannerData(parsed.value);
    setStatus('Preview updated from editor.');
  });

  saveButton.addEventListener('click', () => {
    const parsed = parseEditorJson(editorTextarea.value);
    if (parsed.error) {
      setStatus(`Invalid JSON: ${parsed.error.message}`, true);
      return;
    }
    const snippet = createRoadtripJsSnippet(parsed.value);
    openWhatsAppWithText(snippet);
    setStatus('Opening WhatsApp with updated planner JS...');
  });

  copyButton.addEventListener('click', async () => {
    const parsed = parseEditorJson(editorTextarea.value);
    if (parsed.error) {
      setStatus(`Invalid JSON: ${parsed.error.message}`, true);
      return;
    }
    const snippet = createRoadtripJsSnippet(parsed.value);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(snippet);
        setStatus('Planner JS copied to clipboard.');
      } catch (error) {
        setStatus('Copy failed. Please copy manually.', true);
      }
    } else {
      setStatus('Clipboard not available. Copy manually.', true);
    }
  });

  updateEditorTextarea(initialData);
  setStatus(
    initialSource === 'browser'
      ? 'Loaded planner from browser storage.'
      : 'Loaded planner from server config.'
  );
}

function renderPlanner(data) {
  const planner = document.getElementById('planner');
  const typeFilterContainer = document.getElementById('type-filter');
  const travelTotal = document.getElementById('travel-total');

  if (!planner || !typeFilterContainer || !travelTotal) {
    return;
  }

  const typeFilterInputs = Array.from(typeFilterContainer.querySelectorAll('input[type="checkbox"]'));
  const typeFilterLabels = Array.from(typeFilterContainer.querySelectorAll('.filter-checkbox-label'));
  if (typeFilterInputs.length === 0) {
    return;
  }

  const getMinutes = (duration) => {
    if (!duration) return 0;
    const match = duration.match(/(\d+)h\s*(\d+)?m?/);
    if (!match) return 0;
    const hours = Number(match[1] || 0);
    const minutes = Number(match[2] || 0);
    return hours * 60 + minutes;
  };

  const formatMinutes = (minutesTotal) => {
    const hours = Math.floor(minutesTotal / 60);
    const minutes = minutesTotal % 60;
    if (hours && minutes) return `${hours}h ${minutes}m`;
    if (hours) return `${hours}h`;    
    return `${minutes}m`;
  };

  const getDirectionsUrl = (item) => {
    if (item.directionUrl) {
      return item.directionUrl;
    }

    if (item.from && item.to) {
      const origin = encodeURIComponent(item.from.trim());
      const destination = encodeURIComponent(item.to.trim());
      const mode = item.travelMode ? `&travelmode=${encodeURIComponent(item.travelMode)}` : '';
      return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}${mode}`;
    }

    return null;
  };

  const getMapUrl = (item) => {
    if (item.mapUrl) {
      return item.mapUrl;
    }

    if (item.type === 'Travel') {
      return getDirectionsUrl(item);
    }

    return null;
  };

  const calculateDuration = (item) => {
    if (!item.start || !item.end) return 0;
    const [startHour, startMin] = item.start.split(':').map(Number);
    const [endHour, endMin] = item.end.split(':').map(Number);
    const startTotalMin = startHour * 60 + startMin;
    const endTotalMin = endHour * 60 + endMin;
    return Math.max(0, endTotalMin - startTotalMin);
  };

  const totalTravelMinutes = data.days.reduce((sum, day) => {
    return day.items.reduce((daySum, item) => {
      if (item.type === 'Travel') {
        return daySum + calculateDuration(item);
      }
      return daySum;
    }, 0) + sum;
  }, 0);

  travelTotal.textContent = `Total travel time: ${formatMinutes(totalTravelMinutes)}`;

  const render = () => {
    const selectedValues = typeFilterInputs.filter((input) => input.checked).map((input) => input.value);
    const showAll = selectedValues.includes('All') || selectedValues.length === 0;

    planner.innerHTML = '';

    data.days.forEach((day) => {
      const visibleItems = day.items.filter((item) => {
        return showAll || selectedValues.includes(item.type);
      });

      if (visibleItems.length === 0) {
        return;
      }

      const dayCard = createElement('article', { className: 'day-card' });
      const titleRow = createElement('div', { className: 'day-title' });

      const title = createElement('h2', { text: day.date });
      const dayActions = createElement('div', { className: 'day-actions' });
      const dayIndex = data.days.indexOf(day);
      const addBtn = createElement('button', {
        text: '+ Add item',
        className: 'btn add-item-btn',
        attrs: { type: 'button', title: `Add item to ${day.date}` }
      });
      addBtn.addEventListener('click', () => {
        window.openAddItemModal(dayIndex);
      });

      dayActions.append(addBtn);
      titleRow.append(title, dayActions);
      dayCard.appendChild(titleRow);

      const itemList = createElement('ul', { className: 'item-list' });

      visibleItems.forEach((item, visibleIndex) => {
        // Find the actual item index in the day's items array
        const actualItemIndex = day.items.indexOf(item);

        const row = createElement('li', { className: 'item-row' });
        const badge = createElement('span', { className: `badge ${item.type}`, text: item.type });
        const titleBlock = createElement('div', { className: 'item-body' });
        const heading = createElement('strong', { text: item.title });
        const note = createElement('p', { text: item.notes || 'No additional notes.' });

        titleBlock.append(heading, note);

        const timeInfo = createElement('div', { className: 'item-meta' });
        const timeParts = [];
        if (item.start && item.end) {
          timeParts.push(`${item.start}-${item.end}`);
          const durationMinutes = calculateDuration(item);
          if (durationMinutes > 0) {
            timeParts.push(`(${formatMinutes(durationMinutes)})`);
          }
        } else if (item.start) {
          timeParts.push(item.start);
        } else if (item.end) {
          timeParts.push(item.end);
        }

        timeInfo.textContent = timeParts.join(' ') || 'Time TBD';

        if (item.type === 'Hotel') {
          timeInfo.textContent = item.start ? `${item.start}` : 'Hotel night';
        }

        const mapUrl = getMapUrl(item);

        if (mapUrl) {
          const label = item.type === 'Travel' ? 'Directions' : 'Map';
          const mapLink = createElement('a', {
            text: label,
            className: 'map-link',
            attrs: {
              href: mapUrl,
              target: '_blank',
              rel: 'noopener noreferrer'
            }
          });
          timeInfo.append(' ', mapLink);
        }

        // Create controls
        const controls = createElement('div', { className: 'item-controls' });

        const editBtn = createElement('button', {
          text: '✎',
          className: 'icon-btn',
          attrs: { title: 'Edit item' }
        });
        editBtn.addEventListener('click', () => {
          window.openItemModal(dayIndex, actualItemIndex);
        });

        const upBtn = createElement('button', {
          text: '↑',
          className: 'icon-btn',
          attrs: { title: 'Move up' }
        });
        upBtn.addEventListener('click', () => {
          window.moveItemUp(dayIndex, actualItemIndex);
        });
        if (actualItemIndex === 0) upBtn.disabled = true;

        const downBtn = createElement('button', {
          text: '↓',
          className: 'icon-btn',
          attrs: { title: 'Move down' }
        });
        downBtn.addEventListener('click', () => {
          window.moveItemDown(dayIndex, actualItemIndex);
        });
        if (actualItemIndex === day.items.length - 1) downBtn.disabled = true;

        controls.append(editBtn, upBtn, downBtn);

        row.append(badge, titleBlock, timeInfo, controls);
        itemList.appendChild(row);
      });

      dayCard.appendChild(itemList);
      planner.appendChild(dayCard);
    });

    if (planner.children.length === 0) {
      planner.innerHTML = '<div class="empty-state">No items match this filter. Clear the filter to show the planner again.</div>';
    }
  };

  const syncAllCheckbox = () => {
    const allCheckbox = typeFilterInputs.find((input) => input.value === 'All');
    const checkedTypes = typeFilterInputs.filter((input) => input.checked && input.value !== 'All');

    if (allCheckbox && checkedTypes.length > 0) {
      allCheckbox.checked = false;
    }

    if (allCheckbox && checkedTypes.length === typeFilterInputs.length - 1) {
      allCheckbox.checked = true;
    }
  };

  if (typeFilterContainer.dataset.listenersAttached !== 'true') {
    typeFilterInputs.forEach((input) => {
      input.addEventListener('change', () => {
        const allCheckbox = typeFilterInputs.find((item) => item.value === 'All');
        const otherCheckboxes = typeFilterInputs.filter((item) => item.value !== 'All');

        if (input.value === 'All') {
          otherCheckboxes.forEach((other) => {
            other.checked = input.checked;
          });
        } else {
          const checkedOtherCount = otherCheckboxes.filter((item) => item.checked).length;
          if (allCheckbox) {
            allCheckbox.checked = checkedOtherCount === otherCheckboxes.length;
          }
        }

        if (allCheckbox && allCheckbox.checked && !input.checked && input.value === 'All') {
          typeFilterInputs.forEach((other) => {
            other.checked = other.value === 'All';
          });
        }

        render();
      });
    });

    typeFilterLabels.forEach((label) => {
      const checkbox = label.previousElementSibling;
      if (!checkbox || checkbox.tagName !== 'INPUT') {
        return;
      }

      label.addEventListener('click', (event) => {
        event.preventDefault();
        checkbox.checked = !checkbox.checked;
        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });

    typeFilterContainer.dataset.listenersAttached = 'true';
  }

  render();
}

function getInitialPlannerData(serverData) {
  const preferredSource = getPreferredConfigSource();
  const storedData = getBrowserStoredData();

  if (preferredSource === 'browser' && storedData) {
    return {
      data: storedData,
      source: 'browser'
    };
  }

  if (preferredSource !== 'server' && storedData) {
    return {
      data: storedData,
      source: 'browser'
    };
  }

  return {
    data: serverData,
    source: 'server'
  };
}

const roadtripPayload = typeof roadtripData !== 'undefined' ? roadtripData : window.roadtripData;

if (roadtripPayload) {
  serverRoadtripData = cloneData(roadtripPayload);
  const initialPlanner = getInitialPlannerData(serverRoadtripData);
  currentRoadtripData = cloneData(initialPlanner.data);
  setupModalHandlers();
  setupPlannerEditor(currentRoadtripData, serverRoadtripData, initialPlanner.source);
  renderPlanner(currentRoadtripData);
} else {
  console.error('Road trip data file failed to load.');
}
